﻿
Partial Class central
    Inherits System.Web.UI.Page

End Class
