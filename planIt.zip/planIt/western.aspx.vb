﻿
Partial Class western
    Inherits System.Web.UI.Page

End Class
