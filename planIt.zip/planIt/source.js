var numberOfScreens = 2; // set number of screens (1 or 2 or 3)
 
var blockName = new Array(); // set names of blocks
blockName[1] = 'planIt, Mumbai local journey planner!';
blockName[2] = 'Your valuable feedback';

