﻿Imports System.Data.SqlClient
Imports System.Data
Imports Structures

Partial Class _Default
    Inherits System.Web.UI.Page

    Public Shared con As New SqlConnection(ConfigurationManager.ConnectionStrings("dbJourney").ConnectionString)

    Public Shared Function GetIPAddress() As String
        Dim context As System.Web.HttpContext = System.Web.HttpContext.Current

        Dim sIPAddress As String = context.Request.ServerVariables("HTTP_X_FORWARDED_FOR")

        If String.IsNullOrEmpty(sIPAddress) Then
            Return context.Request.ServerVariables("REMOTE_ADDR")
        Else
            Dim ipArray As String() = sIPAddress.Split(New [Char]() {","c})
            Return ipArray(0)
        End If
    End Function

    Private Sub RecordHistory()
        Dim cValue As String = Guid.NewGuid.ToString
        Dim cCount As String = 1

        If IsNothing(Request.Cookies("trackit")) Then
            Response.Cookies.Add(New HttpCookie("trackit", cValue))
            Response.Cookies.Add(New HttpCookie("countit", 1))
        Else
            cValue = Request.Cookies("trackit").Value
            cCount += Convert.ToInt32(Request.Cookies("countit").Value)
            Response.Cookies("countit").Value = cCount
        End If

        Dim cmd As New SqlCommand("INSERT INTO tblSearchHistory(Source,Destination,Date,time,delay,IP,cookieValue,browserAgent,planType,reachtime) VALUES(" + ddlSource.SelectedValue + "," + ddlDest.SelectedValue + ",'" + Now.Month.ToString + "/" + Now.Day.ToString + "/" + Now.Year.ToString + "','" + Now.ToShortTimeString + "'," + ddlDelay.SelectedValue + ",'" + GetIPAddress() + "','" + cValue + "','" + Request.UserAgent + "','" + CheckBox1.Checked.ToString + "','" + DropDownList1.SelectedValue.ToString + ":" + DropDownList2.SelectedValue.ToString + "') ", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()

    End Sub

    Dim SearchTrainByLeaving
    Protected Sub btnSearch_Click(sender As Object, e As System.EventArgs) Handles btnSearch.Click
        RecordHistory()

        If ddlSource.SelectedValue = ddlDest.SelectedValue Then
            divSuggestion.InnerText = "Its really interesting that you want to travel on station by a train!!!"
        Else
            Select Case CheckBox1.Checked
                Case False : SearchTrainByLeaving = New SearchTrainByLeaving
                    SearchTrainByLeaving.t1 = Now.AddMinutes(Convert.ToInt32(ddlDelay.SelectedValue))

                Case True : SearchTrainByLeaving = New SearchTrainByReaching
                    SearchTrainByLeaving.t1 = New DateTime(Now.Year, Now.Month, Now.Day, Convert.ToInt32(DropDownList1.SelectedValue), Convert.ToInt32(DropDownList2.SelectedValue), 0)

            End Select

            SearchTrainByLeaving.LoadStations()

            SearchTrainByLeaving.Source = SearchTrainByLeaving.StationList(Convert.ToInt32(ddlSource.SelectedValue))
            SearchTrainByLeaving.dest = SearchTrainByLeaving.StationList(Convert.ToInt32(ddlDest.SelectedValue))
            SearchTrainByLeaving.Delay = Convert.ToInt32(ddlDelay.SelectedValue)


            If SearchTrainByLeaving.dest.isWestern And SearchTrainByLeaving.Source.isWestern Then
                'Western direct algo
                divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(SearchTrainByLeaving.GetWesternDirect(SearchTrainByLeaving.t1))
                'Consider Andheri to Mahim harbour line later

            Else
                If SearchTrainByLeaving.dest.isCentral And SearchTrainByLeaving.Source.isCentral Then
                    'Centra direct algo
                    divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(SearchTrainByLeaving.GetCentralDirect(SearchTrainByLeaving.t1))

                ElseIf SearchTrainByLeaving.dest.isharbour And SearchTrainByLeaving.Source.isharbour Then
                    'Harbour direct algo

                    Dim temp As RouteSuggesions = SearchTrainByLeaving.GetHarbourDirect(SearchTrainByLeaving.t1)

                    If (SearchTrainByLeaving.Source.StationID < 4 And SearchTrainByLeaving.dest.isWestern) Or (SearchTrainByLeaving.dest.StationID < 4 And SearchTrainByLeaving.Source.isWestern) Then
                        'Source to Dadar to Dest
                        Dim temp2 As RouteSuggesions = SearchTrainByLeaving.GetCSTAndheriDirect(SearchTrainByLeaving.t1)

                        If temp.ReachingTime > temp2.ReachingTime Then
                            divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(temp2)
                        Else
                            divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(temp)
                        End If
                    Else
                        divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(temp)
                    End If

                ElseIf SearchTrainByLeaving.dest.isTransharbour And SearchTrainByLeaving.Source.isTransharbour Then
                    'Thane-Vashi direct algo
                    divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(SearchTrainByLeaving.GetTransHarbourDirect(SearchTrainByLeaving.t1))

                Else
                    'Indirect
                    divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRoutes(SearchTrainByLeaving.GetOtherDirect(SearchTrainByLeaving.t1))
                End If
            End If

        End If
    End Sub

    'Public Function DisplayRouteTabular(S As RouteSuggesions) As String 'List(Of
    '    Dim msg As String = "Your options(s) via this Route to reach earliest!<br /><ol>" 'have " + RoutePlan.Count.ToString + " 

    '    'For Each s As RouteSuggesions In RoutePlan

    '    msg += "<li>Reaching time: " + S.ReachingTime.ToShortTimeString + " with Total joureny time: " + S.Plan.TotalJournyTime.ToString + "<ul>"

    '    Select Case S.Plan.TrainCarList.Count
    '        Case 0
    '            msg += "<li>Sorry to say but no trains available now for your journey! I guess its too late for now.</li>"

    '        Case 1
    '            msg += "<li>Catch " + S.Plan.RouteStartTime(0).ToShortTimeString + ", " + S.Plan.TrainCarList(0) + " car, " + S.Plan.TrainTypeList(0) + " local to " + S.Plan.LocalName(0) + ", from " + S.Plan.RouteStart(0).StationName + "(" + S.Plan.TrainLineList(0) + " line) and you will reach " + S.Plan.RouteEnd(0).StationName + " at " + S.Plan.RouteEndTime(0).ToShortTimeString + " </li>"

    '            If Not S.Plan.RouteEnd(0).StationID = dest.StationID Then
    '                If Now.Hour >= 0 And Now.Hour <= 4 Then
    '                    msg += "<li>This much far or little beyond this station you can reach for now! I am affraid, its too late to trains remain running on this route even at this time.</li>"
    '                Else
    '                    msg += "<li>This much far or little beyond this station you can reach for now! There must not be any train to your destination either direct or by changing routes.</li>"
    '                End If
    '            End If

    '        Case 2
    '            msg += "<li>Catch " + S.Plan.RouteStartTime(0).ToShortTimeString + ", " + S.Plan.TrainCarList(0) + " car, " + S.Plan.TrainTypeList(0) + " local to " + S.Plan.LocalName(0) + ", from " + S.Plan.RouteStart(0).StationName + "(" + S.Plan.TrainLineList(0) + " line) and you will reach only junction " + S.Plan.RouteEnd(0).StationName + " at " + S.Plan.RouteEndTime(0).ToShortTimeString + " </li>"
    '            msg += "<li>Now from " + S.Plan.RouteStart(1).StationName + "(" + S.Plan.TrainLineList(1) + " line) catch " + S.Plan.RouteStartTime(1).ToShortTimeString + ", " + S.Plan.TrainCarList(1) + " car, " + S.Plan.TrainTypeList(1) + " local to " + S.Plan.LocalName(1) + ", and you will reach " + S.Plan.RouteEnd(1).StationName + " at " + S.Plan.RouteEndTime(1).ToShortTimeString + " </li>"

    '            If Not S.Plan.RouteEnd(1).StationID = dest.StationID Then
    '                If Now.Hour >= 0 And Now.Hour <= 4 Then
    '                    msg += "<li>This much far or little beyond this station you can reach for now! I am affraid, its too late to trains remain running on this route even at this time.</li>"
    '                Else
    '                    msg += "<li>This much far or little beyond this station you can reach for now! There must not be any train to your destination either direct or by changing routes.</li>"
    '                End If
    '            End If

    '        Case Is > 2

    '            msg += "<li>Catch " + S.Plan.RouteStartTime(0).ToShortTimeString + ", " + S.Plan.TrainCarList(0) + " car, " + S.Plan.TrainTypeList(0) + " local to " + S.Plan.LocalName(0) + ", from " + S.Plan.RouteStart(0).StationName + "(" + S.Plan.TrainLineList(0) + " line) and you will reach 1st junction " + S.Plan.RouteEnd(0).StationName + " at " + S.Plan.RouteEndTime(0).ToShortTimeString + " </li>"
    '            Dim i As Integer

    '            For i = 1 To S.Plan.TrainCarList.Count - 2
    '                msg += "<li>now Catch " + S.Plan.RouteStartTime(i).ToShortTimeString + ", " + S.Plan.TrainCarList(i) + " car, " + S.Plan.TrainTypeList(i) + " local to " + S.Plan.LocalName(i) + ", from " + S.Plan.RouteStart(i).StationName + "(" + S.Plan.TrainLineList(i) + " line) and you will reach " + S.Plan.RouteEnd(i).StationName + " at " + S.Plan.RouteEndTime(i).ToShortTimeString + " </li>"
    '            Next

    '            msg += "<li>Finally from " + S.Plan.RouteStart(i).StationName + "(" + S.Plan.TrainLineList(i) + " line) catch " + S.Plan.RouteStartTime(i).ToShortTimeString + ", " + S.Plan.TrainCarList(i) + " car, " + S.Plan.TrainTypeList(i) + " local to " + S.Plan.LocalName(i) + ",  and you will reach " + S.Plan.RouteEnd(i).StationName + " at " + S.Plan.RouteEndTime(i).ToShortTimeString + " </li>"

    '            If Not S.Plan.RouteEnd(1).StationID = dest.StationID Then
    '                If Now.Hour >= 0 And Now.Hour <= 4 Then
    '                    msg += "<li>This much far or little beyond this station you can reach for now! I am affraid, its too late to trains remain running on this route even at this time.</li>"
    '                Else
    '                    msg += "<li>This much far or little beyond this station you can reach for now! There must not be any train to your destination either direct or by changing routes.</li>"
    '                End If
    '            End If

    '    End Select
    '    msg += "</ul></li>"
    '    'Next

    '    msg += "</ol>"

    '    Return msg
    'End Function

End Class
