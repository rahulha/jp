﻿Imports System.Data.SqlClient
Imports System.Data
Imports Structures

Partial Class planitMobile
    Inherits System.Web.UI.Page

    Public Shared con As New SqlConnection(ConfigurationManager.ConnectionStrings("dbJourney").ConnectionString)


    Public Shared Function GetIPAddress() As String
        Dim context As System.Web.HttpContext = System.Web.HttpContext.Current

        Dim sIPAddress As String = context.Request.ServerVariables("HTTP_X_FORWARDED_FOR")

        If String.IsNullOrEmpty(sIPAddress) Then
            Return context.Request.ServerVariables("REMOTE_ADDR")
        Else
            Dim ipArray As String() = sIPAddress.Split(New [Char]() {","c})
            Return ipArray(0)
        End If
    End Function

    Private Sub RecordHistory()
        Dim cValue As String = Guid.NewGuid.ToString
        Dim cCount As String = 1

        If IsNothing(Request.Cookies("trackit")) Then
            Response.Cookies.Add(New HttpCookie("trackit", cValue))
            Response.Cookies.Add(New HttpCookie("countit", 1))
        Else
            cValue = Request.Cookies("trackit").Value
            cCount += Convert.ToInt32(Request.Cookies("countit").Value)
            Response.Cookies("countit").Value = cCount
        End If

        Dim cmd As New SqlCommand("INSERT INTO tblSearchHistory(Source,Destination,Date,time,delay,IP,cookieValue,browserAgent,number,type,planType,reachtime) VALUES(" + ddlSource.SelectedValue + "," + ddlDest.SelectedValue + ",'" + Now.Month.ToString + "/" + Now.Day.ToString + "/" + Now.Year.ToString + "','" + Now.ToShortTimeString + "'," + ddlDelay.SelectedValue + ",'" + GetIPAddress() + "','" + cValue + "','" + Request.UserAgent + "','" + Request.QueryString("n").ToString + "','" + Request.QueryString("type").ToString + "'," + RadioButtonList1.SelectedValue + ",'" + DropDownList1.SelectedValue.ToString + ":" + DropDownList2.SelectedValue.ToString + "') ", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()

    End Sub

    Dim SearchTrainByLeaving
    Protected Sub btnSearch_Click(sender As Object, e As System.EventArgs) Handles btnSearch.Click

        RecordHistory()

        If ddlSource.SelectedValue = ddlDest.SelectedValue Then
            divSuggestion.InnerText = "Its really interesting that you want to travel on station by a train!!!"
        Else
            Select Case RadioButtonList1.SelectedValue
                Case 0 : SearchTrainByLeaving = New SearchTrainByLeaving
                    SearchTrainByLeaving.t1 = Now.AddMinutes(Convert.ToInt32(ddlDelay.SelectedValue))

                Case 1 : SearchTrainByLeaving = New SearchTrainByReaching
                    SearchTrainByLeaving.t1 = New DateTime(Now.Year, Now.Month, Now.Day, Convert.ToInt32(DropDownList1.SelectedValue), Convert.ToInt32(DropDownList2.SelectedValue), 0)

            End Select

            SearchTrainByLeaving.LoadStations()

            SearchTrainByLeaving.Source = SearchTrainByLeaving.StationList(Convert.ToInt32(ddlSource.SelectedValue))
            SearchTrainByLeaving.dest = SearchTrainByLeaving.StationList(Convert.ToInt32(ddlDest.SelectedValue))
            SearchTrainByLeaving.Delay = Convert.ToInt32(ddlDelay.SelectedValue)


            If SearchTrainByLeaving.dest.isWestern And SearchTrainByLeaving.Source.isWestern Then
                'Western direct algo
                divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(SearchTrainByLeaving.GetWesternDirect(SearchTrainByLeaving.t1))
                'Consider Andheri to Mahim harbour line later

            Else
                If SearchTrainByLeaving.dest.isCentral And SearchTrainByLeaving.Source.isCentral Then
                    'Centra direct algo
                    divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(SearchTrainByLeaving.GetCentralDirect(SearchTrainByLeaving.t1))

                ElseIf SearchTrainByLeaving.dest.isharbour And SearchTrainByLeaving.Source.isharbour Then
                    'Harbour direct algo

                    Dim temp As RouteSuggesions = SearchTrainByLeaving.GetHarbourDirect(SearchTrainByLeaving.t1)

                    If (SearchTrainByLeaving.Source.StationID < 4 And SearchTrainByLeaving.dest.isWestern) Or (SearchTrainByLeaving.dest.StationID < 4 And SearchTrainByLeaving.Source.isWestern) Then
                        'Source to Dadar to Dest
                        Dim temp2 As RouteSuggesions = SearchTrainByLeaving.GetCSTAndheriDirect(SearchTrainByLeaving.t1)

                        If temp.ReachingTime > temp2.ReachingTime Then
                            divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(temp2)
                        Else
                            divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(temp)
                        End If
                    Else
                        divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(temp)
                    End If

                ElseIf SearchTrainByLeaving.dest.isTransharbour And SearchTrainByLeaving.Source.isTransharbour Then
                    'Thane-Vashi direct algo
                    divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRouteNarrative(SearchTrainByLeaving.GetTransHarbourDirect(SearchTrainByLeaving.t1))

                Else
                    'Indirect
                    divSuggestion.InnerHtml = SearchTrainByLeaving.DisplayRoutes(SearchTrainByLeaving.GetOtherDirect(SearchTrainByLeaving.t1))
                End If
            End If

        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'If Not IsPostBack Then
        '    If IsNothing(Request.QueryString("type")) Then
        '        Response.Redirect("../Default.aspx")
        '    End If
        'End If
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        If RadioButtonList1.SelectedIndex <> -1 Then

            Select Case RadioButtonList1.SelectedValue
                Case 0 : searchtime.Visible = False
                Case 1 : searchtime.Visible = True
            End Select

        End If
    End Sub
End Class
