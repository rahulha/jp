var num = 2;
var windowWidth = $(window).width();
var windowHeight = $(window).height();
var left1 = 10;
var left2 = left1 - windowWidth;
var wrapperTop = 10;
function anim1to2(){
$('#place').css({'left':left2});
$('#button1to2').hide();			
$('#button2to1').show();
};
function anim2to1(){
$('#place').css({'left':left1});
$('#button1to2').show();			
$('#button2to1').hide();
};
$(document).ready(function(){
$('#button1to2').click(function(){
anim1to2();
});
$('#button2to1').click(function(){
anim2to1();
});
$('#place').css({'left':left1,'top':wrapperTop,'width':windowWidth+windowWidth});
$('#wrapper1').css({'width':windowWidth-20});
$('#wrapper2').css({'width':windowWidth-100,'left':windowWidth+40,'background-position': Math.floor( (windowWidth-161)/2)});
$('#name2').css({'left':windowWidth+10});
$('#button2to1').css({'left':windowWidth+10});
$('#button1to2').css({'left':$('#wrapper1').width()-30});
});