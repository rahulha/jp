﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data

Public MustInherit Class Structures

    Public Shared con As New SqlConnection(ConfigurationManager.ConnectionStrings("dbJourney").ConnectionString)

    Public Shared StationList As New Hashtable
    Public Shared Sub LoadStations()
        If StationList.Count = 0 Then

            Dim adp As New SqlDataAdapter("SELECT * FROM tblStations", con)
            Dim dt As New DataTable

            If Not con.State = ConnectionState.Open Then
                con.Open()
            End If

            adp.Fill(dt)
            con.Close()

            For Each rw As DataRow In dt.Rows
                'If Not StationList.ContainsKey(Convert.ToInt32(rw("StationNo"))) Then

                Dim Source As New Station
                Source.StationID = Convert.ToInt32(rw("StationNo"))
                Source.StationName = rw("StationName").ToString
                Source.isCentral = Convert.ToBoolean(rw("central"))
                Source.isWestern = Convert.ToBoolean(rw("western"))
                Source.isharbour = Convert.ToBoolean(rw("habrour"))
                Source.isTransharbour = Convert.ToBoolean(rw("transharnour"))
                Source.isFast = Convert.ToBoolean(rw("Fast"))

                StationList.Add(Source.StationID, Source)

                'End If
            Next

        End If
    End Sub

    Public Shared ReadOnly Property getStation(Name As String) As Station
        Get
            If Name = "Sandhurst Rd" Then
                Return StationList(3)
            Else
                For Each s As DictionaryEntry In StationList
                    Dim s1 As Station = s.Value
                    If s1.StationName.Equals(Name, StringComparison.InvariantCultureIgnoreCase) Then
                        Return s1
                        Exit For
                    End If
                Next
            End If

        End Get
    End Property

    Public Class RouteSuggesions
        Public Index As Integer
        Public Plan As New TrainPlan
        Public ReachingTime As DateTime
    End Class

    Public Class TrainPlan
        Public LocalName, TrainNameList, TrainTypeList, TrainLineList, TrainCarList As New List(Of String)
        Public RouteStart, RouteEnd As New List(Of Station)
        Public RouteStartTime, RouteEndTime As New List(Of DateTime)
        Public RouteJournyTime As New List(Of TimeSpan)
        'Public NextRemainTrains As New DataSet

        Public Junctions As New ArrayList
        Public JunctionString As String = ","

        Public TotalJournyTime As New TimeSpan

        Public Sub AddJunction(LocalName As String, Train As String, Type As String, Line As String, Car As String, Start As Station, StartTime As DateTime, Destination As Station, EndTime As DateTime) ', TrainsRemain As DataTable)
            Me.LocalName.Add(LocalName)

            TrainNameList.Add(Train)
            TrainTypeList.Add(Type)
            TrainLineList.Add(Line)
            TrainCarList.Add(Car)
            RouteStart.Add(Start)
            RouteStartTime.Add(StartTime)
            RouteEnd.Add(Destination)

            If StartTime > EndTime Then EndTime = EndTime.AddDays(1)

            RouteEndTime.Add(EndTime)

            RouteJournyTime.Add(EndTime - StartTime)
            TotalJournyTime += EndTime - StartTime
        End Sub

    End Class

    Public Class Station
        Public StationID As Int32
        Public StationName As String
        Public isCentral, isWestern, isharbour, isTransharbour, Fast As Boolean

        Public Property isFast As Boolean
            Get
                If StationID > 78 And StationID < 82 Then
                    If Now.Hour = 17 AndAlso Now.Minute > 15 Then
                        Return False
                    Else
                        Return True
                    End If
                Else
                    Return Fast
                End If
            End Get
            Set(value As Boolean)
                Fast = value
            End Set
        End Property

    End Class

    Public MustOverride Function DisplayRoutes(RoutePlans As List(Of RouteSuggesions)) As String 'List(Of 

    Public MustOverride Function DisplayRouteNarrative(S As RouteSuggesions) As String 'List(Of

End Class
