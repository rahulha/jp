﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data
'Imports Structures

Public Class SearchTrainByReaching
    Inherits Structures

    Public Source, dest As Station
    Public t1 As DateTime, Delay As Integer

    Public Function GetWesternDirect(StartTime As DateTime) As RouteSuggesions
        Dim S As New RouteSuggesions

        Dim SQLQuery As String = "[SelectTrains_western_Descending] '," + Source.StationName + "," + dest.StationName + ",:"
        Dim i As Integer, Tables As Integer = 0

        S.Plan.Junctions.Add(Source.StationName)
        S.Plan.JunctionString = "," + Source.StationName ' SQLQuery += 

        If Source.isFast Then
            If Not dest.isFast Then
                If Source.StationID > dest.StationID Then 'From CH towards malad
                    For i = dest.StationID + 1 To Source.StationID - 1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 3
                            Exit For
                        ElseIf i = 74 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 3
                            Exit For
                        End If
                    Next
                Else 'From Virar towards Churni
                    For i = Source.StationID + 1 To dest.StationID - 1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 3
                            Exit For
                        ElseIf i = 74 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 3
                            Exit For
                        End If
                    Next
                End If

            End If
        Else
            If dest.isFast Then
                If Source.StationID > dest.StationID Then 'From Churni towards virar
                    For i = Source.StationID - 1 To dest.StationID + 1 Step -1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 3
                            Exit For
                        ElseIf i = 75 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 3
                            Exit For
                        End If
                    Next
                Else 'From Malad towards Ch
                    For i = Source.StationID + 1 To dest.StationID - 1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 3
                            Exit For
                        ElseIf i = 74 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 3
                            Exit For
                        End If
                    Next
                End If
            Else
                If Source.StationID > dest.StationID Then 'From Churni towards Malad
                    For i = Source.StationID - 1 To dest.StationID + 1 Step -1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 3
                            Exit For
                        ElseIf i = 75 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 3
                            Exit For
                        End If
                    Next
                    For i = dest.StationID + 1 To Source.StationID - 1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 4
                            Exit For
                        ElseIf i = 74 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 4
                            Exit For
                        End If
                    Next
                Else 'From Malad towards Churni
                    For i = Source.StationID + 1 To dest.StationID - 1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 3
                            Exit For
                        ElseIf i = 74 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 3
                            Exit For
                        End If
                    Next
                    For i = dest.StationID - 1 To Source.StationID + 1 Step -1
                        Dim tempSt As Station = StationList(i)
                        If tempSt.isFast Then
                            S.Plan.JunctionString += "," + tempSt.StationName
                            S.Plan.Junctions.Add(tempSt.StationName)
                            Tables = 4
                            Exit For
                        ElseIf i = 75 Then
                            S.Plan.JunctionString += ",Dadar"
                            S.Plan.Junctions.Add("Dadar")
                            Tables = 4
                            Exit For
                        End If
                    Next
                End If
            End If
        End If

        S.Plan.JunctionString += "," + dest.StationName + ","

        S.Plan.Junctions.Add(dest.StationName)
        If Tables > 0 Then SQLQuery += S.Plan.JunctionString + ":"

        Return SelectStations(SQLQuery, Tables, StartTime)
    End Function

    Public Function GetCentralDirect(StartTime As DateTime) As RouteSuggesions
        Dim S As New RouteSuggesions

        Dim SQLQuery As String = "[SelectTrains_central_Descending] '," + Source.StationName + "," + dest.StationName + ",:"
        Dim i As Integer, Tables As Integer = 0

        S.Plan.Junctions.Add(Source.StationName)
        S.Plan.JunctionString = "," + Source.StationName


        If Source.StationID < 41 And dest.StationID < 41 Then ' CST & Karjat

            If Source.isFast Then
                If Not dest.isFast Then
                    If Source.StationID < dest.StationID Then 'From CST towards Diva
                        For i = dest.StationID - 1 To Source.StationID + 1 Step -1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 3
                                Exit For
                            End If
                        Next
                    Else 'From Karjat/Kasara towards Chinchpokhali
                        For i = dest.StationID + 1 To Source.StationID - 1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 3
                                Exit For
                            End If
                        Next
                    End If
                End If
            Else
                If dest.isFast Then
                    If Source.StationID < dest.StationID Then 'From Chinchpokhali towards Kalyan
                        For i = Source.StationID + 1 To dest.StationID - 1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 3
                                Exit For
                            End If
                        Next
                    Else 'From Diva towards CST
                        For i = Source.StationID - 1 To dest.StationID + 1 Step -1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 3
                                Exit For
                            End If
                        Next
                    End If
                Else
                    If Source.StationID < dest.StationID Then 'From Chinchpokhali towards Diva
                        For i = Source.StationID + 1 To dest.StationID - 1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 3
                                Exit For
                            End If
                        Next
                        For i = dest.StationID - 1 To Source.StationID + 1 Step -1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 4
                                Exit For
                            End If
                        Next
                    Else 'From Diva towards Chinchpokhali
                        For i = Source.StationID - 1 To dest.StationID + 1 Step -1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 3
                                Exit For
                            End If
                        Next
                        For i = dest.StationID + 1 To Source.StationID - 1
                            Dim tempSt As Station = StationList(i)
                            If tempSt.isFast Then
                                S.Plan.JunctionString += "," + tempSt.StationName
                                S.Plan.Junctions.Add(tempSt.StationName)
                                Tables = 4
                                Exit For
                            End If
                        Next
                    End If
                End If
            End If

        ElseIf Source.StationID < 26 And dest.StationID > 40 Then ' CST to Kasara

            If Source.isFast Then
                Dim tempSt As Station = StationList(26)
                S.Plan.JunctionString += "," + tempSt.StationName
                S.Plan.Junctions.Add(tempSt.StationName)
                Tables = 3
            Else
                For i = Source.StationID + 1 To 26
                    Dim tempSt As Station = StationList(i)
                    If tempSt.isFast Then
                        S.Plan.JunctionString += "," + tempSt.StationName
                        S.Plan.Junctions.Add(tempSt.StationName)
                        Tables = 3
                        Exit For
                    End If
                Next
            End If

        ElseIf Source.StationID > 40 And dest.StationID < 26 Then ' Kasara to CST

            If dest.isFast Then
                Dim tempSt As Station = StationList(26)
                S.Plan.JunctionString += "," + tempSt.StationName
                S.Plan.Junctions.Add(tempSt.StationName)
                Tables = 3
            Else
                For i = dest.StationID + 1 To 26
                    Dim tempSt As Station = StationList(i)
                    If tempSt.isFast Then
                        S.Plan.JunctionString += "," + tempSt.StationName
                        S.Plan.Junctions.Add(tempSt.StationName)
                        Tables = 3
                        Exit For
                    End If
                Next
            End If

        ElseIf Source.StationID > 26 And Source.StationID < 41 And dest.StationID > 40 Then ' Khopoli to Kasara
            Dim tempSt As Station

            If Source.StationID > 35 Then
                tempSt = StationList(35)
                S.Plan.JunctionString += "," + tempSt.StationName
                S.Plan.Junctions.Add(tempSt.StationName)
                Tables = 3
            Else
                Tables = 2
            End If

            tempSt = StationList(26)
            S.Plan.JunctionString += "," + tempSt.StationName
            S.Plan.Junctions.Add(tempSt.StationName)

        ElseIf Source.StationID > 40 And dest.StationID > 26 And dest.StationID < 41 Then ' Kasara to Karjat
            Dim tempSt As Station

            If dest.StationID > 35 Then
                tempSt = StationList(35)
                S.Plan.JunctionString += "," + tempSt.StationName
                S.Plan.Junctions.Add(tempSt.StationName)
                Tables = 3
            Else
                Tables = 2
            End If

            tempSt = StationList(26)
            S.Plan.JunctionString += "," + tempSt.StationName
            S.Plan.Junctions.Add(tempSt.StationName)

            'ElseIf Source.StationID > 40 And dest.StationID > 40 Then ' Shahad & Kasara
            'No need to do anything
        End If

        S.Plan.JunctionString += "," + dest.StationName + ","
        S.Plan.Junctions.Add(dest.StationName)

        If Tables > 0 Then SQLQuery += S.Plan.JunctionString + ":"

        Return SelectStations(SQLQuery, Tables, StartTime)
    End Function

    Public Function GetHarbourDirect(StartTime As DateTime) As RouteSuggesions
        Dim tables As Integer = 0

        Dim src As String = Source.StationName
        Dim des As String = dest.StationName

        If Source.StationID = 3 Then
            src = "Sandhurst Rd"
        End If

        If dest.StationID = 3 Then
            des = "Sandhurst Rd"
        End If

        Dim SQLQuery As String = "[SelectTrains_harbour_Descending] '," + src + "," + des + ",:"

        If (dest.isWestern And Source.isharbour) Or (Source.isWestern And dest.isharbour) Then
            tables = 3
            SQLQuery += "," + src + ",Vadala Road," + des + ",:"
        End If

        Return SelectStations(SQLQuery, tables, StartTime)
    End Function

    Public Function GetCSTAndheriDirect(StartTime As DateTime) As RouteSuggesions

        Dim SQLQuery As String = "[SelectTrains_CSTAndheri_Descending] '," + Source.StationName + ",Dadar," + dest.StationName + ",:"

        Return SelectStations(SQLQuery, 3, StartTime, True)
    End Function

    Public Function GetTransHarbourDirect(StartTime As DateTime) As RouteSuggesions
        Dim S As New RouteSuggesions
        Dim tables As Integer = 0

        Dim SQLQuery As String = "[SelectTrains_harbour_Descending] '," + Source.StationName + "," + dest.StationName + ",:"

        If ((Source.StationID = 19 Or Source.StationID < 54) And (dest.StationID > 94)) Or ((dest.StationID = 19 Or dest.StationID < 54) And (Source.StationID > 94)) Then
            SQLQuery += "," + Source.StationName + ",Jui Nagar," + dest.StationName + ",:"
            S.Plan.Junctions.Add(Source)
            S.Plan.Junctions.Add(getStation("Jui Nagar"))
            S.Plan.Junctions.Add(dest)
            tables = 3
        End If

        Return SelectStations(SQLQuery, tables, StartTime)
    End Function

    Public Function GetOtherDirect(StartTime As DateTime) As List(Of RouteSuggesions) 'List(Of
        Dim adp As New SqlDataAdapter("SelectRoutes '" + Source.StationID.ToString + "','" + dest.StationID.ToString() + "'", con) '"SELECT * FROM tblStations WHERE StationNO in (" + ddlSource.SelectedValue.ToString + "," + ddlDest.SelectedValue.ToString + ")", con)
        Dim dt As New DataTable

        If Not con.State = ConnectionState.Open Then
            con.Open()
        End If

        adp.Fill(dt)
        con.Close()

        Dim junctionList As New List(Of List(Of Station)), strJunctions() As String, i, j As Integer, junctionString As New List(Of String)

        For Each rw As DataRow In dt.Rows
            If Not String.IsNullOrEmpty(rw(3).ToString) Then
                Dim juncs As New List(Of Station)
                Dim str As String = ","

                juncs.Add(Source)

                strJunctions = rw(3).ToString.Split(",")
                Dim route As String = rw(1).ToString

                For i = 1 To strJunctions.Count - 2
                    Dim stationName As Station = StationList(Convert.ToInt32(strJunctions(i)))
                    If route.Contains("," + strJunctions(i) + ",") AndAlso stationName.StationID <> dest.StationID AndAlso stationName.StationID <> Source.StationID Then
                        juncs.Add(stationName)
                        str += strJunctions(i).ToString + ","
                    End If

                Next

                juncs.Add(dest)
                junctionList.Add(juncs)
                junctionString.Add(str)
            End If
        Next

        i = 0

        While i < junctionString.Count - 1
            j = i + 1

            While j < junctionString.Count
                If junctionString(i) = junctionString(j) Then
                    junctionString.RemoveAt(j)
                    junctionList.RemoveAt(j)
                Else
                    j += 1
                End If
            End While
            i += 1
        End While

        'todo: Consider multiple routes

        Dim FinalSuggestionList As New List(Of RouteSuggesions) 'List(Of

        For Each juncs As List(Of Station) In junctionList

            t1 = StartTime
            Dim temp, temp2 As New RouteSuggesions

            For i = juncs.Count - 2 To 0 Step -1

                Source = juncs(i)
                dest = juncs(i + 1)

                If dest.isWestern And Source.isWestern Then
                    'Western direct algo
                    temp = GetWesternDirect(t1)
                Else
                    If dest.isCentral And Source.isCentral Then
                        'Centra direct algo
                        temp = GetCentralDirect(t1)
                    End If

                    If dest.isharbour And Source.isharbour Then
                        'Harbour direct algo

                        temp = GetHarbourDirect(t1)

                        If (Source.StationID < 4 And dest.StationID > 67 And dest.StationID < 74) Or (dest.StationID < 4 And Source.StationID > 67 And Source.StationID < 74) Then
                            'Source to Dadar to Dest
                            Dim temp3 As RouteSuggesions = GetCSTAndheriDirect(t1)

                            If temp.ReachingTime > temp3.ReachingTime Then
                                temp = temp3
                            End If
                        End If

                    ElseIf dest.isTransharbour And Source.isTransharbour Then
                        'Thane-Vashi direct algo
                        temp = GetTransHarbourDirect(t1)
                    End If
                End If

                For j = 0 To temp.Plan.TrainCarList.Count - 1
                    temp2.Plan.AddJunction(temp.Plan.TrainCarList(j), temp.Plan.TrainNameList(j), temp.Plan.TrainTypeList(j), temp.Plan.TrainLineList(j), temp.Plan.TrainCarList(j), temp.Plan.RouteStart(j), temp.Plan.RouteStartTime(j), temp.Plan.RouteEnd(j), temp.Plan.RouteEndTime(j)) ', New DataTable)
                    t1 = temp.Plan.RouteStartTime(j)
                Next
                If temp2.ReachingTime < temp.ReachingTime Then temp2.ReachingTime = temp.ReachingTime
                t1 = SubtractMinutes(t1, Delay)
            Next

            FinalSuggestionList.Add(temp2)
        Next

        Return FinalSuggestionList
    End Function

    Public Function SelectStations(SQLQuery As String, MainStationCount As Integer, t1 As DateTime, Optional SkipDirect As Boolean = False, Optional SkipInDirect As Boolean = False) As RouteSuggesions
        Dim S As New RouteSuggesions
        Dim TempIndirect As New TrainPlan, tempIndirectReachingTime As DateTime = t1.AddDays(1)
        S.ReachingTime = tempIndirectReachingTime

        Dim adp As New SqlDataAdapter(SQLQuery + "','" + dest.StationName + "',''", con)
        Dim ds As New DataSet

        If Not con.State = ConnectionState.Open Then
            con.Open()
        End If

        adp.Fill(ds)
        con.Close()

        Dim t2 As DateTime
        Dim i As Integer = 0
        Dim rw As DataRow

        If Not SkipDirect Then

            While i < ds.Tables(0).Rows.Count
                rw = ds.Tables(0).Rows(i)

                Dim StartTimeString() As String = rw(5).ToString.Split(",")
                t2 = Convert.ToDateTime(rw(10).ToString) ' StartTimeString(0).Split("-")(1))

                If t1.Hour = 23 And t2.Hour = 0 Then t2 = t2.AddDays(1)

                If t1 >= t2 Then 'And t1.AddHours(1) <= t2 
                    S.Plan.AddJunction(rw("EndStation").ToString, rw("Train").ToString, rw("Type").ToString, rw("line").ToString, rw("car").ToString, Source, Convert.ToDateTime(rw(11)), dest, t2) ', ds.Tables(0).Clone)
                    S.ReachingTime = Convert.ToDateTime(StartTimeString(StartTimeString.Count - 1).Split("-")(1))
                    If t1 > S.ReachingTime Then S.ReachingTime = S.ReachingTime.AddDays(1)
                    Exit While
                Else
                    ds.Tables(0).Rows.Remove(rw)
                End If
            End While

        End If

        If Not SkipInDirect Then
            Dim counter As Integer = 2
            If SkipDirect Then counter = 0

            For j As Integer = MainStationCount + counter - 1 To counter Step -1
                i = 0
                While i < ds.Tables(j).Rows.Count
                    rw = ds.Tables(j).Rows(i)

                    Dim StartTimeString() As String = rw(5).ToString.Split(",")
                    t2 = Convert.ToDateTime(rw(10)) 'StartTimeString(0).Split("-")(1))

                    'If t1 > t2 Then t2 = t2.AddDays(1)

                    If S.Plan.TrainCarList.Count > 0 Then
                        If t1 >= t2 And Not S.Plan.TrainNameList(0).Equals(rw("train").ToString, StringComparison.InvariantCultureIgnoreCase) Then 'And t1.AddHours(1) <= t2 
                            TempIndirect.AddJunction(rw("EndStation").ToString, rw("Train").ToString, rw("Type").ToString, rw("line").ToString, rw("car").ToString, getStation(StartTimeString(0).Split("-")(0)), Convert.ToDateTime(rw(11)), getStation(StartTimeString(StartTimeString.Count - 1).Split("-")(0)), t2) ', ds.Tables(j).Clone) ' StartTimeString(StartTimeString.Count - 1).Split("-")(1))
                            If tempIndirectReachingTime < Convert.ToDateTime(rw(10)) Then tempIndirectReachingTime = Convert.ToDateTime(rw(10))

                            'If t1 > tempIndirectReachingTime Then tempIndirectReachingTime = tempIndirectReachingTime.AddDays(1)

                            t1 = SubtractMinutes(Convert.ToDateTime(rw(11)), Delay) 'StartTimeString(StartTimeString.Count - 1).Split("-")(1))

                            Exit While
                        Else
                            ds.Tables(j).Rows.Remove(rw)
                        End If

                    Else

                        If t1 >= t2 Then 'And t1.AddHours(1) <= t2 
                            TempIndirect.AddJunction(rw("EndStation").ToString, rw("Train").ToString, rw("Type").ToString, rw("line").ToString, rw("car").ToString, getStation(StartTimeString(0).Split("-")(0)), Convert.ToDateTime(rw(11)), getStation(StartTimeString(StartTimeString.Count - 1).Split("-")(0)), t2) ', ds.Tables(j).Clone) 
                            If tempIndirectReachingTime < Convert.ToDateTime(rw(10)) Then tempIndirectReachingTime = Convert.ToDateTime(rw(10))

                            'If t1 > tempIndirectReachingTime Then tempIndirectReachingTime = tempIndirectReachingTime.AddDays(1)

                            t1 = SubtractMinutes(Convert.ToDateTime(rw(11)), Delay)  'StartTimeString(StartTimeString.Count - 1).Split("-")(1))

                            Exit While
                        Else
                            ds.Tables(j).Rows.Remove(rw)
                        End If

                    End If

                End While
            Next
            If Not SkipDirect Then
                'If TempIndirect.TrainCarList.Count = MainStationCount - 1 Then
                If S.Plan.TrainCarList.Count > 0 Then
                    If TempIndirect.RouteStart.Count > 0 Then
                        If S.Plan.RouteStartTime(S.Plan.RouteStartTime.Count - 1) < TempIndirect.RouteStartTime(TempIndirect.RouteStart.Count - 1) And TempIndirect.RouteStart.Count > 0 Then
                            If TempIndirect.RouteStart(TempIndirect.RouteStart.Count - 1).StationID = Source.StationID Then
                                S.Plan = TempIndirect
                                S.ReachingTime = tempIndirectReachingTime
                            End If
                        End If
                    End If
                Else
                    S.Plan = TempIndirect
                    S.ReachingTime = tempIndirectReachingTime
                End If
                'End If
            Else
                S.Plan = TempIndirect
                S.ReachingTime = tempIndirectReachingTime
            End If
        End If

        Return S
    End Function

    Public Function SubtractMinutes(D As DateTime, Minutes As Integer) As DateTime
        Dim m As Integer = D.Minute
        Dim h As Integer = D.Hour
        Dim day As Integer = D.Day
        Dim month As Integer = D.Month
        Dim year As Integer = D.Year

        m -= Minutes
        If m < 0 Then
            h -= 1
            m = 0
            If h < 0 Then
                day -= 1
                h = 0
                If day < 1 Then
                    month -= 1
                    day = 1
                    If month < 1 Then
                        year -= 1
                        month = 1
                    End If
                End If
            End If
        End If

        Return New DateTime(year, month, day, h, m, 0)

    End Function

    Public Overrides Function DisplayRoutes(RoutePlans As List(Of RouteSuggesions)) As String 'List(Of 
        Dim msg As String = "You have " + RoutePlans.Count.ToString + " Route(s) for this Journey sorted by earliest you reach!!<br /><br />"

        Dim i, j As Integer

        While i < RoutePlans.Count

            'For i = 0 To RoutePlans.Count - 1
            If RoutePlans(i).Plan.TotalJournyTime = New TimeSpan(0, 0, 0) Then
                RoutePlans.RemoveAt(i)
            Else
                For j = 0 To RoutePlans.Count - 2 - i
                    If dest.StationID < 41 And dest.StationID > 35 And Source.StationID < 35 Then
                        If RoutePlans(j).Plan.RouteEnd(RoutePlans(j).Plan.RouteEnd.Count - 1).StationID > RoutePlans(j + 1).Plan.RouteEnd(RoutePlans(j + 1).Plan.RouteEnd.Count - 1).StationID Then
                            Dim temp As RouteSuggesions = RoutePlans(j)
                            RoutePlans(j) = RoutePlans(j + 1)
                            RoutePlans(j + 1) = temp
                        End If

                        'ElseIf Source.StationID > 35 And dest.StationID < 35 Then

                    Else
                        If RoutePlans(j).ReachingTime > RoutePlans(j + 1).ReachingTime Then

                            Dim temp As RouteSuggesions = RoutePlans(j)
                            RoutePlans(j) = RoutePlans(j + 1)
                            RoutePlans(j + 1) = temp

                        End If
                    End If

                Next
                i += 1
            End If
            'Next

        End While

        For Each R As RouteSuggesions In RoutePlans
            msg += DisplayRouteNarrative(R) + "<br /><br />"
        Next

        Return msg
    End Function

    Public Overrides Function DisplayRouteNarrative(S As RouteSuggesions) As String 'List(Of
        Dim msg As String = "Your options(s) via this Route<br /><br /><Div class='ol'>" 'have " + RoutePlan.Count.ToString + " 

        'For Each s As RouteSuggesions In RoutePlan

        msg += "<Reachingbox>Reaching time: " + S.ReachingTime.ToShortTimeString + "</Reachingbox> with <Reachingbox>Total joureny time: " + S.Plan.TotalJournyTime.ToString + "</Reachingbox><ul class='ul'>"

        Select Case S.Plan.TrainCarList.Count
            Case 0
                msg += "<li>Sorry to say but no trains available now for your journey! I guess its too late for now.</li>"

            Case 1
                msg += "<li>Catch <highlightbox>" + S.Plan.RouteStartTime(0).ToShortTimeString + "</highlightbox>, " + S.Plan.TrainCarList(0) + " car, <highlightbox>" + S.Plan.TrainTypeList(0) + "</highlightbox> local to <highlightbox>" + S.Plan.LocalName(0) + "</highlightbox>, from <highlightbox>" + S.Plan.RouteStart(0).StationName + "(" + S.Plan.TrainLineList(0) + " line)</highlightbox> and you will reach " + S.Plan.RouteEnd(0).StationName + " at <highlightbox>" + S.Plan.RouteEndTime(0).ToShortTimeString + "</highlightbox> </li>"

                If Not S.Plan.RouteEnd(0).StationID = dest.StationID Then
                    If Now.Hour >= 0 And Now.Hour <= 4 Then
                        msg += "<li>This much far or little beyond this station you can reach for now! I am affraid, its too late to trains remain running on this route even at this time.</li>"
                    Else
                        msg += "<li>This much far or little beyond this station you can reach for now! There must not be any train to your destination either direct or by changing routes.</li>"
                    End If
                End If

            Case 2
                msg += "<li>Catch <highlightbox>" + S.Plan.RouteStartTime(1).ToShortTimeString + "</highlightbox>, " + S.Plan.TrainCarList(1) + " car, <highlightbox>" + S.Plan.TrainTypeList(1) + "</highlightbox> local to <highlightbox>" + S.Plan.LocalName(1) + "</highlightbox>, from <highlightbox>" + S.Plan.RouteStart(1).StationName + "(" + S.Plan.TrainLineList(1) + " line)</highlightbox> and you will reach only junction " + S.Plan.RouteEnd(1).StationName + " at <highlightbox>" + S.Plan.RouteEndTime(1).ToShortTimeString + "</highlightbox> </li>"
                msg += "<li>Now from <highlightbox>" + S.Plan.RouteStart(0).StationName + "(" + S.Plan.TrainLineList(0) + " line)</highlightbox> catch <highlightbox>" + S.Plan.RouteStartTime(0).ToShortTimeString + "</highlightbox>, " + S.Plan.TrainCarList(0) + " car, <highlightbox>" + S.Plan.TrainTypeList(0) + "</highlightbox> local to <highlightbox>" + S.Plan.LocalName(0) + "</highlightbox>, and you will reach " + S.Plan.RouteEnd(0).StationName + " at <highlightbox>" + S.Plan.RouteEndTime(0).ToShortTimeString + "</highlightbox></li>"

                If Not S.Plan.RouteEnd(1).StationID = dest.StationID Then
                    If Now.Hour >= 0 And Now.Hour <= 4 Then
                        msg += "<li>This much far or little beyond this station you can reach for now! I am affraid, its too late to trains remain running on this route even at this time.</li>"
                    Else
                        msg += "<li>This much far or little beyond this station you can reach for now! There must not be any train to your destination either direct or by changing routes.</li>"
                    End If
                End If

            Case Is > 2
                Dim counter As Integer = S.Plan.RouteStartTime.Count - 1

                msg += "<li>Catch <highlightbox>" + S.Plan.RouteStartTime(counter).ToShortTimeString + "</highlightbox>, " + S.Plan.TrainCarList(counter) + " car, <highlightbox>" + S.Plan.TrainTypeList(counter) + "</highlightbox> local to <highlightbox>" + S.Plan.LocalName(counter) + "</highlightbox>, from <highlightbox>" + S.Plan.RouteStart(counter).StationName + "(" + S.Plan.TrainLineList(counter) + " line)</highlightbox> and you will reach 1st junction " + S.Plan.RouteEnd(counter).StationName + " at <highlightbox>" + S.Plan.RouteEndTime(counter).ToShortTimeString + "</highlightbox> </li>"
                Dim i As Integer

                For i = S.Plan.TrainCarList.Count - 2 To 1 Step -1
                    msg += "<li>now Catch <highlightbox>" + S.Plan.RouteStartTime(i).ToShortTimeString + "</highlightbox>, " + S.Plan.TrainCarList(i) + " car, <highlightbox>" + S.Plan.TrainTypeList(i) + "</highlightbox> local to <highlightbox>" + S.Plan.LocalName(i) + "</highlightbox>, from <highlightbox>" + S.Plan.RouteStart(i).StationName + "(" + S.Plan.TrainLineList(i) + " line)</highlightbox> and you will reach " + S.Plan.RouteEnd(i).StationName + " at <highlightbox>" + S.Plan.RouteEndTime(i).ToShortTimeString + "</highlightbox></li>"
                Next

                msg += "<li>Finally from <highlightbox>" + S.Plan.RouteStart(0).StationName + "(" + S.Plan.TrainLineList(0) + " line)</highlightbox> catch <highlightbox>" + S.Plan.RouteStartTime(0).ToShortTimeString + "</highlightbox>, " + S.Plan.TrainCarList(0) + " car, <highlightbox>" + S.Plan.TrainTypeList(0) + "</highlightbox> local to <highlightbox>" + S.Plan.LocalName(0) + "</highlightbox>,  and you will reach " + S.Plan.RouteEnd(0).StationName + " at <highlightbox>" + S.Plan.RouteEndTime(0).ToShortTimeString + "</highlightbox></li>"

                If Not S.Plan.RouteEnd(1).StationID = dest.StationID Then
                    If Now.Hour >= 0 And Now.Hour <= 4 Then
                        msg += "<li>This much far or little beyond this station you can reach for now! I am affraid, its too late to trains remain running on this route even at this time.</li>"
                    Else
                        msg += "<li>This much far or little beyond this station you can reach for now! There must not be any train to your destination either direct or by changing routes.</li>"
                    End If
                End If

        End Select
        msg += "</ul>"
        'Next

        msg += "</Div>"

        Return msg
    End Function

End Class
