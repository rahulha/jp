﻿Imports System.Data.SqlClient

Partial Class feedback
    Inherits System.Web.UI.Page
    Public Shared con As New SqlConnection(ConfigurationManager.ConnectionStrings("dbJourney").ConnectionString)

    Public Shared Function GetIPAddress() As String
        Dim context As System.Web.HttpContext = System.Web.HttpContext.Current

        Dim sIPAddress As String = context.Request.ServerVariables("HTTP_X_FORWARDED_FOR")

        If String.IsNullOrEmpty(sIPAddress) Then
            Return context.Request.ServerVariables("REMOTE_ADDR")
        Else
            Dim ipArray As String() = sIPAddress.Split(New [Char]() {","c})
            Return ipArray(0)
        End If
    End Function

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        Dim cValue As String = Guid.NewGuid.ToString
        Dim cCount As String = 1

        If IsNothing(Request.Cookies("trackit")) Then
            Response.Cookies.Add(New HttpCookie("trackit", cValue))
            Response.Cookies.Add(New HttpCookie("countit", 1))
        Else
            cValue = Request.Cookies("trackit").Value
            cCount += Convert.ToInt32(Request.Cookies("countit").Value)
            Response.Cookies("countit").Value = cCount
        End If

        Dim cmd As New SqlCommand("INSERT INTO tblSuggestions(Suggestion,Name,Date,time,IP,cookie,browserAgent) VALUES('" + TextBox1.Text + "','" + TextBox2.Text + "','" + Now.ToShortDateString + "','" + Now.ToShortTimeString + "','" + GetIPAddress() + "','" + cValue + "','" + Request.UserAgent + "') ", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        TextBox1.Text = ""
        TextBox2.Text = ""
        Label1.Text = "Your message is sent to Admin. Thanks for choosing planIt!"
        Label1.Visible = True
    End Sub
End Class
