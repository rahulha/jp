﻿
Partial Class trans
    Inherits System.Web.UI.Page

End Class
